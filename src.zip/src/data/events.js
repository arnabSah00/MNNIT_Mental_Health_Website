// ---------------------------------------------------------------------------
// EVENTS DATA
// ---------------------------------------------------------------------------
// Every event uses the SAME structure, so the detail page can render any of
// them. To add a new event, copy one object and fill in the fields.
//
// Fields:
//   id          unique url-friendly slug (used in the address bar: /event/:id)
//   title       full event name
//   shortName   abbreviation/short label shown on the timeline
//   date        human-readable date (e.g. "June 15–19, 2025")
//   sortDate    ISO date (YYYY-MM-DD) used ONLY for ordering newest-first
//   venue       where it happened
//   guest       main guest / chief guest / lead organiser
//   description main write-up (can be multiple sentences)
//   images      array of image URLs. Leave the placeholder URLs for now and
//               swap in real photos later (drop files in src/assets and import,
//               or use a hosted URL).
// ---------------------------------------------------------------------------

// Simple colored placeholder generator so the carousel has something to show
// until real photos are added. Replace `images: [...]` with real URLs later.
const placeholder = (label, color) =>
  `https://placehold.co/800x500/${color}/ffffff?text=${encodeURIComponent(label)}`

export const EVENTS = [
  {
    id: 'reccb',
    title: 'RECCB 2026 — Research Excellence & Campus Culture Building',
    shortName: 'RECCB',
    date: 'June 22–26, 2026',
    sortDate: '2026-06-22',
    venue: 'Online Mode',
    guest: 'Conveners: Dr. Dinesh Singh & Dr. Rajitha B',
    description:
      'A five-day online Faculty Upgradation Program organised by the Dean (Student Welfare) Office, MNNIT Allahabad. RECCB 2026 was conceptualised to strengthen faculty competencies in building a collaborative, inclusive, and academically enriching campus environment, while enhancing their effectiveness as research mentors and academic leaders. The programme covered campus culture and positive environment building, research supervision, research scholar management, and building an inclusive campus environment. Through expert-led sessions, interactive discussions, and experience-sharing, participants gained practical insights into nurturing research scholars, maintaining academic integrity, promoting diversity, equity and inclusion, and contributing to the holistic development of the institution. An e-certificate was provided to all eligible participants.',
    images: [
      placeholder('RECCB 1', 'e67e22'),
      placeholder('RECCB 2', 'd35400'),
      placeholder('RECCB 3', 'f39c12')
    ]
  },
  {
    id: 'idy',
    title: 'International Day of Yoga 2026 — "Yoga Sangam"',
    shortName: 'IDY',
    date: 'June 20–21, 2026',
    sortDate: '2026-06-21',
    venue: 'MP Hall, MNNIT Allahabad',
    guest: 'Dr. Prashanta Majee (Yoga Coordinator) & Dr. Dinesh Singh',
    description:
      'Organised by the Student Activity Centre, MNNIT Allahabad as part of the Ministry of Ayush, Government of India activities, the International Day of Yoga was celebrated under the flagship event "Yoga Sangam" with the theme "Yoga for Healthy Ageing". On 20 June a practice session for the Common Yoga Protocol (CYP) was held from 6:30–7:30 A.M. On 21 June, the celebration began with a live stream of the Honourable Prime Minister\'s address (6:30–7:00 A.M.) followed by the execution of the Common Yoga Protocol (7:00–8:00 A.M.). Faculty members, staff, and students participated to immerse themselves in the celebration and make it a grand success.',
    images: [
      placeholder('IDY 1', '27ae60'),
      placeholder('IDY 2', '2ecc71'),
      placeholder('IDY 3', '16a085')
    ]
  },
  {
    id: 'pewp',
    title: 'PEWP 2026 — Pedagogical Excellence & Wellness Program',
    shortName: 'PEWP',
    date: 'June 15–19, 2026',
    sortDate: '2026-06-15',
    venue: 'Online Mode',
    guest: 'Conveners: Dr. Dinesh Singh & Dr. Rajitha B',
    description:
      'A one-week online Faculty Upgradation Program organised by the Dean (Student Welfare) Office, MNNIT Allahabad. PEWP 2026 was designed to strengthen faculty capabilities in contemporary pedagogical approaches, technology-integrated teaching, and academic leadership. Core themes included Outcome-Based Education (OBE) and active pedagogy, technology integration in teaching (EdTech tools), and mental well-being and emotional intelligence for faculty. The programme emphasised learner-centric instruction, digital assessment methodologies, stress management, resilience, and professional well-being. Through expert deliberations, interactive sessions, and hands-on learning, it aimed to develop competent, reflective, and future-ready educators. Registration was free and online on a first-come, first-served basis.',
    images: [
      placeholder('PEWP 1', '2980b9'),
      placeholder('PEWP 2', '3498db'),
      placeholder('PEWP 3', '1abc9c')
    ]
  },
  {
    id: 'surya-namaskar',
    title: 'Surya-Namaskar: A Radiant Way to Healthy Lifestyle',
    shortName: 'Surya Namaskar',
    date: 'June 14, 2026 · 7:00–8:00 A.M.',
    sortDate: '2026-06-14',
    venue: 'MP Hall, MNNIT Allahabad',
    guest: 'Prof. Archana Chahal — Professor & Head, Dept. of Physical Education, University of Allahabad',
    description:
      'A special invited session titled "Surya-namaskar: A Radiant Way to Healthy Lifestyle" delivered by Prof. Archana Chahal, Professor and Head of the Department of Physical Education, University of Allahabad. Hosted by MNNIT Allahabad, the early-morning session guided participants through the practice and benefits of Surya Namaskar, focusing on physical wellness, discipline, and mindfulness as part of a healthy daily lifestyle.',
    images: [
      placeholder('Surya Namaskar 1', 'e74c3c'),
      placeholder('Surya Namaskar 2', 'c0392b'),
      placeholder('Surya Namaskar 3', 'e67e22')
    ]
  },
  {
    id: 'yoga',
    title: 'Kriyayoga Meditation Session',
    shortName: 'Yoga',
    date: 'June 7, 2026 · 7:00–8:00 A.M.',
    sortDate: '2026-06-07',
    venue: 'MP Hall, MNNIT Allahabad',
    guest: 'Yogi Satyam Ji — Kriyayoga Ashram & Research Institute, Jhunsi, Prayagraj',
    description:
      'A special invited session on Kriyayoga Meditation delivered by Yogi Satyam Ji of the Kriyayoga Ashram & Research Institute, Jhunsi, Prayagraj. Hosted by MNNIT Allahabad, this early-morning session introduced participants to Kriyayoga meditation techniques aimed at deepening mental calm, concentration, and inner well-being, supporting both spiritual and mental wellness of the campus community.',
    images: [
      placeholder('Yoga 1', '9b59b6'),
      placeholder('Yoga 2', '8e44ad'),
      placeholder('Yoga 3', '5b3ba6')
    ]
  },
  {
    id: 'expert-talk',
    title: 'Expert Talk — Motivating Young Engineers for Cyber Excellence',
    shortName: 'Expert Talk',
    date: 'November 17, 2025 · 10:00 A.M.–12:00 Noon',
    sortDate: '2025-11-17',
    venue: 'GS-06, MNNIT Allahabad',
    guest: 'Mr. Gurjit Singh — Senior DGM (Retd.), Bharat Electronics Limited, Noida',
    description:
      'An expert talk on "Motivating Young Engineers for Cyber Excellence", delivered by Mr. Gurjit Singh, Senior DGM (Retired) of Bharat Electronics Limited, Noida. Organised by the Department of Computer Science & Engineering, MNNIT Allahabad under the ISEA-III Project (sponsored by MeitY, Government of India), the session was attended by UG, PG, and PhD students along with faculty members. The talk motivated young engineers towards excellence and awareness in the field of cyber security.',
    images: [
      placeholder('Expert Talk 1', '5b3ba6'),
      placeholder('Expert Talk 2', '8b5fbf'),
      placeholder('Expert Talk 3', '4a2d8a')
    ]
  },
  {
    id: 'mhwb',
    title: 'MHWB — Spiritual & Mental Wellbeing Center',
    shortName: 'MHWB',
    date: 'May 2026 (ongoing)',
    sortDate: '2026-05-01',
    venue: 'MNNIT Allahabad Campus',
    guest: 'Health Centre & Spiritual & Mental Wellbeing Center, MNNIT Allahabad',
    description:
      'A campus-wide mental health and wellbeing initiative run jointly by the Institute\'s Health Centre and the Spiritual & Mental Wellbeing Center. Recognising that students\' physical and mental health is essential for concentration and academic success, the initiative provides professional counsellors (for both boys and girls) available at designated hostels and centres on fixed days and times. Counselling support is offered for any anxiety- or stress-related concerns. Beyond scheduled hours, students can reach out to their guardian/HOD, Faculty In-charge (Boys/Girls), the medical officer, or the Dean (Student Welfare) for urgent needs, and may also contact the faculty/associate counsellors via their office email.',
    images: [
      placeholder('MHWB 1', '34495e'),
      placeholder('MHWB 2', '2c3e50'),
      placeholder('MHWB 3', '5b3ba6')
    ]
  }
]

// Newest first (by sortDate). Helper used by the timeline page.
export const getEventsNewestFirst = () =>
  [...EVENTS].sort((a, b) => new Date(b.sortDate) - new Date(a.sortDate))

// Lookup used by the detail page.
export const getEventById = (id) => EVENTS.find((e) => e.id === id)
